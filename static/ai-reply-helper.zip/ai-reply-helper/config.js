// Where the helper's API lives.
window.ARH_API = "https://ai-reply-helper-psi.vercel.app";
