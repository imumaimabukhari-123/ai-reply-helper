// Where the helper's API lives.
window.ARH_API = "http://127.0.0.1:8005";
